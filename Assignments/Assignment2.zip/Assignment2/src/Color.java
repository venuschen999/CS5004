/**
 * Represents the two chess colors.
 */

public enum Color {
  BLACK,
  WHITE
}
